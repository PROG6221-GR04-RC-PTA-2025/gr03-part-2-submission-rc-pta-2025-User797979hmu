﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Speech.Synthesis;
using System.Threading;

namespace ChatbotApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Play the voice greeting
            PlayVoiceGreeting();

            // Display ASCII art (Cybersecurity Awareness Bot logo)
            DisplayAsciiLogo();

            // Greet the user and ask for their name
            string userName = AskUserName();
            if (string.IsNullOrEmpty(userName))
            {
                Console.WriteLine("You didn't enter a name. Please try again.");
                return;
            }

            Console.WriteLine($"Hello, {userName}! Welcome to the Cybersecurity Awareness Bot!");

            // Simulate typing effect and ask user about how they need help
            TypeText("I am here to help you stay safe online by providing some cybersecurity tips...");

            // Start the conversation
            RespondToQueries(userName);
        }

        // Method to play the voice greeting when the chatbot starts
        static void PlayVoiceGreeting()
        {
            try
            {
                SpeechSynthesizer synth = new SpeechSynthesizer();
                Console.WriteLine("Welcome to the Cybersecurity Awareness chatbot!");
                synth.Speak("Welcome to the Cybersecurity Awareness chatbot! Ask me anything about online safety.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error playing the voice greeting: " + ex.Message);
            }
        }

        // Method to display the ASCII logo or art of the chatbot
        static void DisplayAsciiLogo()
        {
            Console.WriteLine(@"
  ____      ____   ___          _______
  |---\     |  |   |  \        /       |
  |  \ \    |  |   |   \      /        |
  |   \ \   |  |   |    \    /     /|  |
  | |  \ \  |  |   |     \  /     / |  |
  | |   \ \ |  |   |      \/     /  |  |
  | |    \ \|  |   |  |\        /   |  |
  | |     \ \  |   |  | \      /    |  |
  |_|      \___|   |__|  \____/     |__|
");
        }

        // Method to ask the user's name and return it
        static string AskUserName()
        {
            Console.Write("What is your name? ");
            string userName = Console.ReadLine();
            return userName;
        }

        // Method to simulate typing effect
        static void TypeText(string message)
        {
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(50); // Simulate typing delay
            }
            Console.WriteLine();
        }

        // Method to respond to user queries about the chatbot's purpose
        static void RespondToQueries(string userName)
        {
            Console.WriteLine("Ask me anything about cybersecurity.");
            Console.WriteLine("Type 'exit' to quit.");

            string input;
            while (true)
            {
                input = Console.ReadLine()?.ToLower();

                if (string.IsNullOrEmpty(input))
                {
                    Console.WriteLine("You didn't enter anything. Please type a valid question.");
                    continue;
                }

                if (input == "exit")
                {
                    Console.WriteLine("Goodbye!");
                    break;
                }

                // Handle specific user queries
                if (input == "how are you?")
                {
                    Console.WriteLine("I'm doing well, thank you for asking!");
                }
                else if (input == "what's your purpose?")
                {
                    Console.WriteLine("My purpose is to help you stay safe online by providing cybersecurity tips and answering your questions.");
                }
                else if (input == "what can I ask you about?")
                {
                    Console.WriteLine("You can ask me about topics like password safety, phishing, and safe browsing.");
                }
                else
                {
                    // Handle cybersecurity-related topics or general queries
                    ProvideCybersecurityResponse(input, userName);
                }
            }
        }

        // Method to provide a response based on cybersecurity knowledge
        static void ProvideCybersecurityResponse(string input, string userName)
        {
            Dictionary<string, string> responses = new Dictionary<string, string>()
            {
                { "phishing", "Phishing is a cyberattack method where attackers try to deceive you into revealing sensitive information like passwords or credit card numbers. Be cautious of unsolicited emails or messages." },
                { "malware", "Malware is malicious software designed to harm or exploit your device. Keep your antivirus software up-to-date and avoid opening suspicious attachments." },
                { "password", "A strong password should be unique and contain a combination of uppercase letters, lowercase letters, numbers, and special characters. Avoid using easily guessable information." },
                { "ransomware", "Ransomware is a type of malware that encrypts your files and demands payment to restore access. Always back up your files and avoid opening suspicious email attachments." },
                { "social engineering", "Social engineering involves manipulating people into revealing confidential information. Be cautious when sharing sensitive information over the phone, email, or social media, and verify the identity of the person requesting it." },
                { "encryption", "Encryption is the process of converting data into a secure format that can only be read by someone with the correct decryption key. Always ensure your sensitive information is encrypted." },
                { "two-factor authentication", "Two-factor authentication (2FA) adds an extra layer of security by requiring two forms of identification before you can access your account. This could be a password and a code sent to your phone." },
                { "vpn", "A Virtual Private Network (VPN) encrypts your internet connection, making it harder for hackers to track your online activities. Use a VPN when accessing public or untrusted networks." },
                { "firewall", "A firewall monitors and controls incoming and outgoing network traffic. Ensure your devices have an active firewall to protect against unauthorized access." }
            };

            bool found = false;
            foreach (var key in responses.Keys)
            {
                if (input.Contains(key))
                {
                    Console.WriteLine(responses[key]);
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                Console.WriteLine("I'm sorry, I didn't understand that. Could you please rephrase or ask about another topic related to cybersecurity?");
            }
        }

        // Memory handling: Get specific tips or responses based on user input
        public static string GetMemoryResponse(string userInput)
        {
            string lowerInput = userInput.ToLower();

            // Store user's name
            if (lowerInput.StartsWith("my name is "))
            {
                string name = userInput.Substring("my name is ".Length).Trim();
                return $"Nice to meet you, {name}! What cybersecurity topic are you interested in today?";
            }
            // Store user's favorite topic
            else if (lowerInput.Contains("interested in "))
            {
                string topic = userInput.Substring(lowerInput.IndexOf("interested in ") + "interested in ".Length).Trim();
                return $"Great! I'll remember that you're interested in {topic}. It's a crucial part of staying safe online.";
            }
            else
            {
                return "Let me know what you'd like to talk about regarding cybersecurity!";
            }
        }

        // Method to provide a random phishing tip
        static void ProvidePhishingTip()
        {
            List<string> phishingTips = new List<string>
            {
                "Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organizations.",
                "Never click on suspicious links in emails or messages. Verify the link before clicking.",
                "Watch out for urgent requests or threats in emails. Scammers often try to create a sense of urgency.",
                "Enable multi-factor authentication (MFA) on your accounts for an extra layer of security against phishing attempts."
            };

            Random random = new Random();
            int index = random.Next(phishingTips.Count);
            Console.WriteLine(phishingTips[index]);
        }
    }
}
